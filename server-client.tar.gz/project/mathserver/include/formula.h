#ifndef _FORMULA_H_
#define _FORMULA_H_

int main_matinv(int argc, char** argv, int soln, int clientId);
int main_kmeans(int argc, char** argv, int soln, int clientId);

#endif
